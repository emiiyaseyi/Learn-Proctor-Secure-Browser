<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for mod_learnguard.
 *
 * @package    mod_learnguard
 * @author     Michael Adeniran <michaeladeniransnr@gmail.com>
 * @copyright  2025 Michael Adeniran
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

function xmldb_learnguard_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    // -----------------------------------------------------------------------
    // v1.0.5 — Add all columns introduced after v1.0.0, plus own question bank
    // -----------------------------------------------------------------------
    if ($oldversion < 2025051805) {

        // ---- learnguard table: add missing columns ----
        $table = new xmldb_table('learnguard');

        $cols = [
            ['gradepass',        'number', null, null, XMLDB_NOTNULL, null, '0'],
            ['timeopen',         'int',    10,   null, XMLDB_NOTNULL, null, '0'],
            ['timeclose',        'int',    10,   null, XMLDB_NOTNULL, null, '0'],
            ['show_results',     'int',    1,    null, XMLDB_NOTNULL, null, '1'],
            ['results_released', 'int',    10,   null, XMLDB_NOTNULL, null, '0'],
        ];

        foreach ($cols as [$name, $type, $precision, $scale, $notnull, $sequence, $default]) {
            if (!$dbman->field_exists($table, $name)) {
                if ($type === 'number') {
                    $field = new xmldb_field($name, XMLDB_TYPE_NUMBER, '10,5', null, $notnull, $sequence, $default);
                } else {
                    $field = new xmldb_field($name, XMLDB_TYPE_INTEGER, $precision, null, $notnull, $sequence, $default);
                }
                $dbman->add_field($table, $field);
            }
        }

        // ---- learnguard_qbank_cats ----
        if (!$dbman->table_exists('learnguard_qbank_cats')) {
            $t = new xmldb_table('learnguard_qbank_cats');
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('name',        XMLDB_TYPE_CHAR,   '255', null, XMLDB_NOTNULL, null, null);
            $t->add_field('description', XMLDB_TYPE_TEXT,   null,  null, null, null, null);
            $t->add_field('sortorder',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timemodified',XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $dbman->create_table($t);
        }

        // ---- learnguard_qbank ----
        if (!$dbman->table_exists('learnguard_qbank')) {
            $t = new xmldb_table('learnguard_qbank');
            $t->add_field('id',                  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('categoryid',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('name',                 XMLDB_TYPE_CHAR,   '255',null, XMLDB_NOTNULL, null, null);
            $t->add_field('questiontext',         XMLDB_TYPE_TEXT,   null,  null, null, null, null);
            $t->add_field('questiontextformat',   XMLDB_TYPE_INTEGER, '4',  null, XMLDB_NOTNULL, null, '1');
            $t->add_field('qtype',                XMLDB_TYPE_CHAR,   '20', null, XMLDB_NOTNULL, null, 'multichoice');
            $t->add_field('defaultmark',          XMLDB_TYPE_NUMBER, '10,5',null, XMLDB_NOTNULL, null, '1');
            $t->add_field('shuffleanswers',       XMLDB_TYPE_INTEGER, '1',  null, XMLDB_NOTNULL, null, '1');
            $t->add_field('generalfeedback',      XMLDB_TYPE_TEXT,   null,  null, null, null, null);
            $t->add_field('generalfeedbackformat',XMLDB_TYPE_INTEGER, '4',  null, XMLDB_NOTNULL, null, '1');
            $t->add_field('timecreated',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timemodified',         XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('createdby',            XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $t->add_index('categoryid', XMLDB_INDEX_NOTUNIQUE, ['categoryid']);
            $dbman->create_table($t);
        }

        // ---- learnguard_qbank_answers ----
        if (!$dbman->table_exists('learnguard_qbank_answers')) {
            $t = new xmldb_table('learnguard_qbank_answers');
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('questionid',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('answertext',  XMLDB_TYPE_TEXT,   null,  null, null, null, null);
            $t->add_field('answertextformat', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '1');
            $t->add_field('fraction',    XMLDB_TYPE_NUMBER, '10,5',null, XMLDB_NOTNULL, null, '0');
            $t->add_field('feedback',    XMLDB_TYPE_TEXT,   null,  null, null, null, null);
            $t->add_field('sortorder',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $t->add_index('questionid', XMLDB_INDEX_NOTUNIQUE, ['questionid']);
            $dbman->create_table($t);
        }

        // ---- learnguard_responses ----
        if (!$dbman->table_exists('learnguard_responses')) {
            $t = new xmldb_table('learnguard_responses');
            $t->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('attemptid',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('slotid',       XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('questionid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('responsedata', XMLDB_TYPE_TEXT,   null,  null, null, null, null);
            $t->add_field('fraction',     XMLDB_TYPE_NUMBER, '10,5',null, XMLDB_NOTNULL, null, '0');
            $t->add_field('state',        XMLDB_TYPE_CHAR,   '20', null, XMLDB_NOTNULL, null, 'todo');
            $t->add_field('timecreated',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $t->add_index('attemptid', XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $t->add_index('slotid',    XMLDB_INDEX_NOTUNIQUE, ['slotid']);
            $dbman->create_table($t);
        }

        // ---- learnguard_qbank_cats: seed a default category ----
        if (!$DB->record_exists('learnguard_qbank_cats', [])) {
            $DB->insert_record('learnguard_qbank_cats', (object)[
                'name'         => 'General',
                'description'  => 'Default question category',
                'sortorder'    => 0,
                'timecreated'  => time(),
                'timemodified' => time(),
            ]);
        }

        upgrade_mod_savepoint(true, 2025051805, 'learnguard');
    }

    // -----------------------------------------------------------------------
    // v1.0.6 — Randomization support + per-attempt question ordering
    // -----------------------------------------------------------------------
    if ($oldversion < 2025051806) {

        // Add randomize / num_questions to learnguard table.
        $table = new xmldb_table('learnguard');
        foreach ([
            ['randomize',     'int',  1],
            ['num_questions', 'int', 10],
        ] as [$name, $type, $len]) {
            if (!$dbman->field_exists($table, $name)) {
                $field = new xmldb_field($name, XMLDB_TYPE_INTEGER, $len, null, XMLDB_NOTNULL, null, '0');
                $dbman->add_field($table, $field);
            }
        }

        // learnguard_attempt_questions table.
        if (!$dbman->table_exists('learnguard_attempt_questions')) {
            $t = new xmldb_table('learnguard_attempt_questions');
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('slotid',      XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('questionid',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('slotnum',     XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $t->add_index('attemptid', XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $dbman->create_table($t);
        }

        upgrade_mod_savepoint(true, 2025051806, 'learnguard');
    }

    // v1.1.4 — add is_global flag to learnguard_proctors so a user can proctor
    //           ALL assessments site-wide without per-activity assignment.
    if ($oldversion < 2025051814) {
        $table = new xmldb_table('learnguard_proctors');
        $field = new xmldb_field('is_global', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'role');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        upgrade_mod_savepoint(true, 2025051814, 'learnguard');
    }

    // v1.1.6 — Phase 3: chat messages, exam PIN, break management, extended time.
    if ($oldversion < 2025051816) {

        // ── learnguard_messages (proctor ↔ student chat) ──────────────────
        $t = new xmldb_table('learnguard_messages');
        if (!$dbman->table_exists($t)) {
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('learnguard',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('senderid',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('sendertype',  XMLDB_TYPE_CHAR,    '20', null, XMLDB_NOTNULL, null, 'student');
            $t->add_field('message',     XMLDB_TYPE_TEXT,    null, null, XMLDB_NOTNULL, null, null);
            $t->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('isseen',      XMLDB_TYPE_INTEGER, '1',  null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary',   XMLDB_KEY_PRIMARY,  ['id']);
            $t->add_index('attemptid', XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $dbman->create_table($t);
        }

        // ── learnguard: access_pin field ──────────────────────────────────
        $lt  = new xmldb_table('learnguard');
        $fld = new xmldb_field('access_pin', XMLDB_TYPE_CHAR, '30', null, XMLDB_NOTNULL, null, '', 'instructions');
        if (!$dbman->field_exists($lt, $fld)) { $dbman->add_field($lt, $fld); }

        // ── learnguard_attempts: break + extended time fields ─────────────
        $at = new xmldb_table('learnguard_attempts');
        foreach ([
            ['extra_time',      XMLDB_TYPE_INTEGER, '10', '0'],  // extra seconds granted by proctor
            ['break_requested', XMLDB_TYPE_INTEGER, '10', '0'],  // unix ts of break request
            ['break_approved',  XMLDB_TYPE_INTEGER, '10', '0'],  // unix ts proctor approved
            ['break_end',       XMLDB_TYPE_INTEGER, '10', '0'],  // unix ts student ended break
        ] as [$fname, $type, $len, $default]) {
            $f = new xmldb_field($fname, $type, $len, null, XMLDB_NOTNULL, null, $default, 'timemodified');
            if (!$dbman->field_exists($at, $f)) { $dbman->add_field($at, $f); }
        }

        upgrade_mod_savepoint(true, 2025051816, 'learnguard');
    }

    // v1.2.1 — Incident management table + notification_hours field.
    if ($oldversion < 2025051821) {

        // learnguard_incidents — incident management for proctors.
        $t = new xmldb_table('learnguard_incidents');
        if (!$dbman->table_exists($t)) {
            $t->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('learnguard',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('attemptid',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('proctoriid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('severity',     XMLDB_TYPE_CHAR,    '10', null, XMLDB_NOTNULL, null, 'medium');
            $t->add_field('title',        XMLDB_TYPE_CHAR,    '255',null, XMLDB_NOTNULL, null, null);
            $t->add_field('description',  XMLDB_TYPE_TEXT,    null, null, XMLDB_NOTNULL, null, null);
            $t->add_field('status',       XMLDB_TYPE_CHAR,    '20', null, XMLDB_NOTNULL, null, 'open');
            $t->add_field('resolution',   XMLDB_TYPE_TEXT,    null, null, false,         null, null);
            $t->add_field('timecreated',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timeresolved', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary',    XMLDB_KEY_PRIMARY,   ['id']);
            $t->add_index('attemptid', XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $dbman->create_table($t);
        }

        // learnguard_essay_grades — manual essay grade overrides.
        $t2 = new xmldb_table('learnguard_essay_grades');
        if (!$dbman->table_exists($t2)) {
            $t2->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t2->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t2->add_field('slotid',      XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t2->add_field('graderid',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t2->add_field('grade',       XMLDB_TYPE_NUMBER,  '10', null, XMLDB_NOTNULL, null, '0', 5);
            $t2->add_field('feedback',    XMLDB_TYPE_TEXT,    null, null, false,         null, null);
            $t2->add_field('timegraded',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t2->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $dbman->create_table($t2);
        }

        // notification_hours on learnguard table — for pre-exam emails.
        $lt  = new xmldb_table('learnguard');
        $fld = new xmldb_field('notification_hours', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'access_pin');
        if (!$dbman->field_exists($lt, $fld)) { $dbman->add_field($lt, $fld); }

        upgrade_mod_savepoint(true, 2025051821, 'learnguard');
    }

    // v1.3.2 — Audio clips table for noise-triggered recordings.
    if ($oldversion < 2025051832) {
        $t = new xmldb_table('learnguard_audio_clips');
        if (!$dbman->table_exists($t)) {
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('userid',      XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $t->add_field('audiodata',   XMLDB_TYPE_TEXT,    null, null, XMLDB_NOTNULL, null, null);
            $t->add_field('duration',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('noise_level', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary',    XMLDB_KEY_PRIMARY,   ['id']);
            $t->add_index('attemptid', XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $dbman->create_table($t);
        }
        upgrade_mod_savepoint(true, 2025051832, 'learnguard');
    }

    // v1.3.4 — Add courseid to learnguard_proctors + learnguard_graders table.
    if ($oldversion < 2025051834) {
        // courseid on proctors for course-level proctor assignment.
        $pt  = new xmldb_table('learnguard_proctors');
        $fld = new xmldb_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'is_global');
        if (!$dbman->field_exists($pt, $fld)) {
            $dbman->add_field($pt, $fld);
        }

        // learnguard_graders — essay grader assignments with anonymous + layer support.
        $gt = new xmldb_table('learnguard_graders');
        if (!$dbman->table_exists($gt)) {
            $gt->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $gt->add_field('learnguard',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $gt->add_field('userid',      XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $gt->add_field('anonymous',   XMLDB_TYPE_INTEGER, '1',  null, XMLDB_NOTNULL, null, '0');
            $gt->add_field('gradelayer',  XMLDB_TYPE_INTEGER, '1',  null, XMLDB_NOTNULL, null, '1');
            $gt->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $gt->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $gt->add_index('learnguard', XMLDB_INDEX_NOTUNIQUE, ['learnguard']);
            $dbman->create_table($gt);
        }

        upgrade_mod_savepoint(true, 2025051834, 'learnguard');
    }

    // v1.3.9 — Face approval requests + messaging tables.
    // Stores pre-exam face match approval requests (keyed by cmid+userid, no attemptid needed).
    if ($oldversion < 2025051839) {
        $fat = new xmldb_table('learnguard_face_approvals');
        if (!$dbman->table_exists($fat)) {
            $fat->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $fat->add_field('cmid',         XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $fat->add_field('userid',       XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $fat->add_field('status',       XMLDB_TYPE_CHAR,    '20', null, XMLDB_NOTNULL, null, 'pending');
            $fat->add_field('passportdata', XMLDB_TYPE_TEXT,    null, null, false,         null, null);
            $fat->add_field('matchpct',     XMLDB_TYPE_INTEGER, '3',  null, XMLDB_NOTNULL, null, '0');
            $fat->add_field('reviewedby',   XMLDB_TYPE_INTEGER, '10', null, false,         null, null);
            $fat->add_field('reviewnote',   XMLDB_TYPE_TEXT,    null, null, false,         null, null);
            $fat->add_field('timecreated',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $fat->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $fat->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $fat->add_index('cmid_userid',  XMLDB_INDEX_NOTUNIQUE, ['cmid', 'userid']);
            $dbman->create_table($fat);
        }

        // learnguard_fa_messages — chat messages tied to face approval requests.
        $fmt = new xmldb_table('learnguard_fa_messages');
        if (!$dbman->table_exists($fmt)) {
            $fmt->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $fmt->add_field('approvalid',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $fmt->add_field('userid',      XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $fmt->add_field('sendertype',  XMLDB_TYPE_CHAR,    '20', null, XMLDB_NOTNULL, null, 'student');
            $fmt->add_field('message',     XMLDB_TYPE_TEXT,    null, null, XMLDB_NOTNULL, null, null);
            $fmt->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $fmt->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $fmt->add_index('approvalid', XMLDB_INDEX_NOTUNIQUE, ['approvalid']);
            $dbman->create_table($fmt);
        }

        upgrade_mod_savepoint(true, 2025051839, 'learnguard');
    }

    // v1.4.3a — Precheck session tracking table.
    if ($oldversion < 2025052004) {
        $pct = new xmldb_table('learnguard_precheck_sessions');
        if (!$dbman->table_exists($pct)) {
            $pct->add_field('id',           XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $pct->add_field('cmid',         XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, null);
            $pct->add_field('userid',       XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, null);
            $pct->add_field('current_step', XMLDB_TYPE_CHAR,    '50',  null, XMLDB_NOTNULL, null, 'welcome');
            $pct->add_field('step_number',  XMLDB_TYPE_INTEGER, '3',   null, XMLDB_NOTNULL, null, '0');
            $pct->add_field('total_steps',  XMLDB_TYPE_INTEGER, '3',   null, XMLDB_NOTNULL, null, '0');
            $pct->add_field('timecreated',  XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, '0');
            $pct->add_field('timemodified', XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, '0');
            $pct->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $pct->add_index('cmid_userid', XMLDB_INDEX_NOTUNIQUE, ['cmid', 'userid']);
            $dbman->create_table($pct);
        }
        upgrade_mod_savepoint(true, 2025052004, 'learnguard');
    }

    // v1.4.3 — Timed results release + question timing per response.
    if ($oldversion < 2025052003) {
        // timeresults on learnguard table: when students can see their results.
        $lt  = new xmldb_table('learnguard');
        $fld = new xmldb_field('timeresults', XMLDB_TYPE_INTEGER, '10', null, false, null, null, 'show_results');
        if (!$dbman->field_exists($lt, $fld)) { $dbman->add_field($lt, $fld); }

        // show_selfcheck on learnguard table: show risk summary to student after finishing.
        $fld2 = new xmldb_field('show_selfcheck', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1', 'timeresults');
        if (!$dbman->field_exists($lt, $fld2)) { $dbman->add_field($lt, $fld2); }

        // timespent on learnguard_responses: track seconds spent on each question.
        $rt  = new xmldb_table('learnguard_responses');
        if ($dbman->table_exists($rt)) {
            $rfld = new xmldb_field('timespent', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'response_data');
            if (!$dbman->field_exists($rt, $rfld)) { $dbman->add_field($rt, $rfld); }
        }

        upgrade_mod_savepoint(true, 2025052003, 'learnguard');
    }

    // v1.6.0 — Per-learner exam scheduling (schedule.php + dual countdown).
    if ($oldversion < 2025052021) {
        $table = new xmldb_table('learnguard_schedules');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('learnguard',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('userid',       XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('timeopen',     XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timeclose',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('createdby',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timecreated',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('learnguard_userid', XMLDB_INDEX_UNIQUE, ['learnguard', 'userid']);
            $dbman->create_table($table);
        }
        upgrade_mod_savepoint(true, 2025052021, 'learnguard');
    }

    // -----------------------------------------------------------------------
    // v1.6.5 — fix snapshot_type values mangled by send_snapshot()'s old
    // PARAM_ALPHA validation (it stripped underscores/digits, e.g.
    // 'screen_capture' was stored as 'screencapture'), which made the
    // Gallery's type filter never match those rows.
    // -----------------------------------------------------------------------
    if ($oldversion < 2025052026) {
        $map = [
            'photoid'          => 'photo_id',
            'screencapture'    => 'screen_capture',
            'randomscreenshot' => 'random_screenshot',
            'multiplefaces'    => 'multiple_faces',
            'multiplepersons'  => 'multiple_persons',
            'backgroundchange' => 'background_change',
            'identitymismatch' => 'identity_mismatch',
        ];
        foreach ($map as $mangled => $correct) {
            $DB->set_field('learnguard_snapshots', 'snapshot_type', $correct, ['snapshot_type' => $mangled]);
        }
        upgrade_mod_savepoint(true, 2025052026, 'learnguard');
    }

    // -----------------------------------------------------------------------
    // v1.6.7 — Per-activity branding overrides (Brand tab on admin.php).
    // -----------------------------------------------------------------------
    if ($oldversion < 2025052028) {
        $table = new xmldb_table('learnguard_brand_overrides');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id',              XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('learnguard',      XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, null);
            $table->add_field('brand_name',      XMLDB_TYPE_CHAR,    '255', null, false,         null, null);
            $table->add_field('brand_primary',   XMLDB_TYPE_CHAR,    '20',  null, false,         null, null);
            $table->add_field('brand_accent',    XMLDB_TYPE_CHAR,    '20',  null, false,         null, null);
            $table->add_field('brand_textcolor', XMLDB_TYPE_CHAR,    '20',  null, false,         null, null);
            $table->add_field('timemodified',    XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('learnguard', XMLDB_INDEX_UNIQUE, ['learnguard']);
            $dbman->create_table($table);
        }
        upgrade_mod_savepoint(true, 2025052028, 'learnguard');
    }

    // -----------------------------------------------------------------------
    // v1.6.7 — Essay grading distribution (Cap+Randomise / Even Split /
    // Manual) for Layer-1 graders, configured on the Graders tab.
    // -----------------------------------------------------------------------
    if ($oldversion < 2025052029) {
        $table = new xmldb_table('learnguard_grading_config');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('learnguard',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('gradingmode',   XMLDB_TYPE_CHAR,    '20', null, XMLDB_NOTNULL, null, 'all');
            $table->add_field('gradingcap',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('learnguard', XMLDB_INDEX_UNIQUE, ['learnguard']);
            $dbman->create_table($table);
        }

        $table2 = new xmldb_table('learnguard_grader_assignments');
        if (!$dbman->table_exists($table2)) {
            $table2->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table2->add_field('learnguard',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table2->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table2->add_field('graderid',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table2->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table2->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table2->add_index('learnguard_attempt', XMLDB_INDEX_UNIQUE, ['learnguard', 'attemptid']);
            $dbman->create_table($table2);
        }

        upgrade_mod_savepoint(true, 2025052029, 'learnguard');
    }

    // -----------------------------------------------------------------------
    // v1.6.5 — catch-up step. The companion quizaccess_learnshield plugin's
    // site-recorded version (2026053105) was higher than every savepoint
    // above, so on a site that received the same out-of-band build, the
    // 2025052021/2025052026/2025052028/2025052029 steps could be silently
    // skipped on upgrade. Re-apply them all here (idempotent — no-ops if
    // already applied).
    // -----------------------------------------------------------------------
    if ($oldversion < 2026053106) {
        // learnguard_schedules (2025052021).
        $table = new xmldb_table('learnguard_schedules');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('learnguard',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('userid',       XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('timeopen',     XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timeclose',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('createdby',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timecreated',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('learnguard_userid', XMLDB_INDEX_UNIQUE, ['learnguard', 'userid']);
            $dbman->create_table($table);
        }

        // snapshot_type mangled value fix (2025052026).
        $map = [
            'photoid'          => 'photo_id',
            'screencapture'    => 'screen_capture',
            'randomscreenshot' => 'random_screenshot',
            'multiplefaces'    => 'multiple_faces',
            'multiplepersons'  => 'multiple_persons',
            'backgroundchange' => 'background_change',
            'identitymismatch' => 'identity_mismatch',
        ];
        foreach ($map as $mangled => $correct) {
            $DB->set_field('learnguard_snapshots', 'snapshot_type', $correct, ['snapshot_type' => $mangled]);
        }

        // learnguard_brand_overrides (2025052028).
        $table = new xmldb_table('learnguard_brand_overrides');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id',              XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('learnguard',      XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, null);
            $table->add_field('brand_name',      XMLDB_TYPE_CHAR,    '255', null, false,         null, null);
            $table->add_field('brand_primary',   XMLDB_TYPE_CHAR,    '20',  null, false,         null, null);
            $table->add_field('brand_accent',    XMLDB_TYPE_CHAR,    '20',  null, false,         null, null);
            $table->add_field('brand_textcolor', XMLDB_TYPE_CHAR,    '20',  null, false,         null, null);
            $table->add_field('timemodified',    XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('learnguard', XMLDB_INDEX_UNIQUE, ['learnguard']);
            $dbman->create_table($table);
        }

        // learnguard_grading_config + learnguard_grader_assignments (2025052029).
        $table = new xmldb_table('learnguard_grading_config');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id',           XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('learnguard',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('gradingmode',   XMLDB_TYPE_CHAR,    '20', null, XMLDB_NOTNULL, null, 'all');
            $table->add_field('gradingcap',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('learnguard', XMLDB_INDEX_UNIQUE, ['learnguard']);
            $dbman->create_table($table);
        }

        $table2 = new xmldb_table('learnguard_grader_assignments');
        if (!$dbman->table_exists($table2)) {
            $table2->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table2->add_field('learnguard',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table2->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table2->add_field('graderid',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table2->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table2->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table2->add_index('learnguard_attempt', XMLDB_INDEX_UNIQUE, ['learnguard', 'attemptid']);
            $dbman->create_table($table2);
        }

        upgrade_mod_savepoint(true, 2026053106, 'learnguard');
    }

    // Essay "marking guide" field on learnguard_qbank (N12).
    if ($oldversion < 2026053107) {
        $table = new xmldb_table('learnguard_qbank');

        $field = new xmldb_field('markingguidance', XMLDB_TYPE_TEXT, null, null, null, null, null, 'generalfeedbackformat');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('markingguidanceformat', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '1', 'markingguidance');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_mod_savepoint(true, 2026053107, 'learnguard');
    }

    // R6/R4: casesensitive on learnguard_qbank + deadline on learnguard_graders.
    if ($oldversion < 2026061603) {
        $qbank = new xmldb_table('learnguard_qbank');
        $field = new xmldb_field('casesensitive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'markingguidanceformat');
        if (!$dbman->field_exists($qbank, $field)) {
            $dbman->add_field($qbank, $field);
        }

        $graders = new xmldb_table('learnguard_graders');
        $field = new xmldb_field('deadline', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'gradelayer');
        if (!$dbman->field_exists($graders, $field)) {
            $dbman->add_field($graders, $field);
        }

        upgrade_mod_savepoint(true, 2026061603, 'learnguard');
    }

    // Mandatory questions: is_mandatory flag on learnguard_qbank.
    if ($oldversion < 2026061604) {
        $qbank = new xmldb_table('learnguard_qbank');
        $field = new xmldb_field('is_mandatory', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'casesensitive');
        if (!$dbman->field_exists($qbank, $field)) {
            $dbman->add_field($qbank, $field);
        }
        upgrade_mod_savepoint(true, 2026061604, 'learnguard');
    }

    // Timer suspend/resume: record when the attempt was suspended so the timer
    // can be restored to the exact remaining time on reinstatement.
    if ($oldversion < 2026061612) {
        $table = new xmldb_table('learnguard_attempts');
        $field = new xmldb_field('timesuspended', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'timemodified');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        upgrade_mod_savepoint(true, 2026061612, 'learnguard');
    }

    // Catch-up: ensure all learnguard_qbank columns exist. Some sites have these
    // steps skipped when their recorded plugin version was already above individual
    // savepoints (2026053107, 2026061603, 2026061604). All checks are idempotent.
    if ($oldversion < 2026061900) {
        $qbanktable = new xmldb_table('learnguard_qbank');

        $field = new xmldb_field('markingguidance', XMLDB_TYPE_TEXT, null, null, null, null, null, 'generalfeedbackformat');
        if (!$dbman->field_exists($qbanktable, $field)) {
            $dbman->add_field($qbanktable, $field);
        }

        $field = new xmldb_field('markingguidanceformat', XMLDB_TYPE_INTEGER, '4', null, XMLDB_NOTNULL, null, '1', 'markingguidance');
        if (!$dbman->field_exists($qbanktable, $field)) {
            $dbman->add_field($qbanktable, $field);
        }

        $field = new xmldb_field('casesensitive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'markingguidanceformat');
        if (!$dbman->field_exists($qbanktable, $field)) {
            $dbman->add_field($qbanktable, $field);
        }

        $field = new xmldb_field('is_mandatory', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'casesensitive');
        if (!$dbman->field_exists($qbanktable, $field)) {
            $dbman->add_field($qbanktable, $field);
        }

        upgrade_mod_savepoint(true, 2026061900, 'learnguard');
    }

    if ($oldversion < 2026061907) {
        // Add violations_suspended to learnguard_attempts so proctors can
        // pause all violation scoring for a specific learner mid-attempt.
        $atttable = new xmldb_table('learnguard_attempts');
        $field = new xmldb_field('violations_suspended', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'is_flagged');
        if (!$dbman->field_exists($atttable, $field)) {
            $dbman->add_field($atttable, $field);
        }

        // Add overridden to learnguard_events so proctors can dismiss a
        // false-positive event and deduct its score_impact from the learner's
        // running risk score.
        $evttable = new xmldb_table('learnguard_events');
        $field = new xmldb_field('overridden', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0', 'score_impact');
        if (!$dbman->field_exists($evttable, $field)) {
            $dbman->add_field($evttable, $field);
        }

        upgrade_mod_savepoint(true, 2026061907, 'learnguard');
    }

    // v2.0.8 — fix decimal essay grades + Moodle-proper response state for essays.
    if ($oldversion < 2026062004) {
        // Ensure learnguard_essay_grades.grade is DECIMAL(10,5) not INT.
        // Sites installed before this column was properly typed would silently truncate
        // decimal marks (e.g. 0.5 stored as 0).
        $table = new xmldb_table('learnguard_essay_grades');
        if ($dbman->table_exists($table)) {
            $field = new xmldb_field('grade', XMLDB_TYPE_NUMBER, '10', null, XMLDB_NOTNULL, null, '0');
            $field->setDecimals(5);
            $dbman->change_field_type($table, $field);
        }

        // Migrate essay learnguard_responses.state to Moodle-proper values:
        //   'graded'       = essay has been manually graded (grade row in learnguard_essay_grades)
        //   'needsgrading' = essay was submitted but not yet manually graded
        // Previously save_grade set state='complete' for both auto-graded MCQ and essays,
        // making it impossible to distinguish without querying learnguard_essay_grades.
        $essayRespRows = $DB->get_recordset_sql(
            "SELECT r.id, r.attemptid, r.slotid FROM {learnguard_responses} r
               JOIN {learnguard_slots} s ON s.id = r.slotid
               JOIN {learnguard_qbank} q ON q.id = s.questionid AND q.qtype = 'essay'
              WHERE r.state = 'complete'"
        );
        foreach ($essayRespRows as $row) {
            $hasGrade = $DB->record_exists('learnguard_essay_grades',
                ['attemptid' => $row->attemptid, 'slotid' => $row->slotid]);
            $DB->set_field('learnguard_responses', 'state',
                $hasGrade ? 'graded' : 'needsgrading', ['id' => $row->id]);
        }
        $essayRespRows->close();

        upgrade_mod_savepoint(true, 2026062004, 'learnguard');
    }

    if ($oldversion < 2026062005) {
        // v2.0.9: No DB schema changes. CASE WHEN in scores/scorematrix now uses
        // state != 'graded' so old state='complete' essays are hidden until re-graded.
        upgrade_mod_savepoint(true, 2026062005, 'learnguard');
    }

    if ($oldversion < 2026062702) {
        // v2.0.13: Add is_global and courseid columns to learnguard_graders to support
        // course-level and site-wide global grader assignments (mirrors learnguard_proctors).
        $table = new xmldb_table('learnguard_graders');
        $fieldGlobal = new xmldb_field('is_global', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($table, $fieldGlobal)) {
            $dbman->add_field($table, $fieldGlobal);
        }
        $fieldCourse = new xmldb_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($table, $fieldCourse)) {
            $dbman->add_field($table, $fieldCourse);
        }
        upgrade_mod_savepoint(true, 2026062702, 'learnguard');
    }

    if ($oldversion < 2026063002) {
        // v2.0.22: Add break_duration + break_deadline to learnguard_attempts.
        // break_duration  = minutes selected by student when requesting break.
        // break_deadline  = unix ts when break auto-expires (break_approved + break_duration*60).
        $tattempts = new xmldb_table('learnguard_attempts');
        $fDur = new xmldb_field('break_duration', XMLDB_TYPE_INTEGER, '5', null, XMLDB_NOTNULL, null, '5');
        if (!$dbman->field_exists($tattempts, $fDur)) {
            $dbman->add_field($tattempts, $fDur);
        }
        $fDead = new xmldb_field('break_deadline', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($tattempts, $fDead)) {
            $dbman->add_field($tattempts, $fDead);
        }

        // v2.0.22: Add extra_attempts + timelimit_override to learnguard_schedules.
        // extra_attempts      = additional attempts granted to this user beyond the activity limit.
        // timelimit_override  = per-user time limit in seconds (0 = use activity default).
        $tsched = new xmldb_table('learnguard_schedules');
        $fExtra = new xmldb_field('extra_attempts', XMLDB_TYPE_INTEGER, '5', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($tsched, $fExtra)) {
            $dbman->add_field($tsched, $fExtra);
        }
        $fTime = new xmldb_field('timelimit_override', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($tsched, $fTime)) {
            $dbman->add_field($tsched, $fTime);
        }

        upgrade_mod_savepoint(true, 2026063002, 'learnguard');
    }

    if ($oldversion < 2026072301) {
        // Add attemptid to learnguard_slots: 0=fixed slot, non-zero=pool-drawn for that attempt.
        $tslots   = new xmldb_table('learnguard_slots');
        $fattmid  = new xmldb_field('attemptid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($tslots, $fattmid)) {
            $dbman->add_field($tslots, $fattmid);
        }

        // Create learnguard_pools table for multi-bank pool rules.
        $tpools = new xmldb_table('learnguard_pools');
        if (!$dbman->table_exists($tpools)) {
            $tpools->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
            $tpools->add_field('learnguard',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $tpools->add_field('catid',       XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $tpools->add_field('drawcount',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '1');
            $tpools->add_field('maxmark',     XMLDB_TYPE_NUMBER,  '10', 5,    XMLDB_NOTNULL, null, '1.0');
            $tpools->add_field('sortorder',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $tpools->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $tpools->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $tpools->add_index('learnguard', XMLDB_INDEX_NOTUNIQUE, ['learnguard']);
            $dbman->create_table($tpools);
        }

        upgrade_mod_savepoint(true, 2026072301, 'learnguard');
    }

    if ($oldversion < 2026072302) {
        // Add skip_precheck to learnguard_schedules so admins can bypass the
        // pre-exam wizard for a specific user on a specific assessment.
        $tsched = new xmldb_table('learnguard_schedules');
        $fSkip  = new xmldb_field('skip_precheck', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        if (!$dbman->field_exists($tsched, $fSkip)) {
            $dbman->add_field($tsched, $fSkip);
        }
        upgrade_mod_savepoint(true, 2026072302, 'learnguard');
    }

    if ($oldversion < 2026072305) {
        // Add exclude_violations to learnguard_schedules so admins can exempt a
        // specific user from selected violation categories (camera, face, audio, etc.).
        // Stored as a comma-separated list, e.g. "camera,audio".
        $tsched = new xmldb_table('learnguard_schedules');
        $fExcl  = new xmldb_field('exclude_violations', XMLDB_TYPE_TEXT, null, null, null, null, null);
        if (!$dbman->field_exists($tsched, $fExcl)) {
            $dbman->add_field($tsched, $fExcl);
        }
        upgrade_mod_savepoint(true, 2026072305, 'learnguard');
    }

    if ($oldversion < 2026073002) {
        // Create answer history table — logs the previous state of a response row
        // before each overwrite, enabling recovery of accidentally lost answers.
        if (!$dbman->table_exists('learnguard_response_history')) {
            $t = new xmldb_table('learnguard_response_history');
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('responseid',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('slotid',      XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('questionid',  XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('responsedata',XMLDB_TYPE_TEXT,    null,  null, null,          null, null);
            $t->add_field('fraction',    XMLDB_TYPE_NUMBER,  '10',  null, XMLDB_NOTNULL, null, '0', '5');
            $t->add_field('state',       XMLDB_TYPE_CHAR,    '20',  null, XMLDB_NOTNULL, null, '');
            $t->add_field('savedbefore', XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timecreated', XMLDB_TYPE_INTEGER, '10',  null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $t->add_index('attemptid', XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $t->add_index('slotid',    XMLDB_INDEX_NOTUNIQUE, ['slotid']);
            $dbman->create_table($t);
        }
        upgrade_mod_savepoint(true, 2026073002, 'learnguard');
    }

    if ($oldversion < 2026073003) {
        // Add per-section time limit to learnguard_pools.
        // 0 = uses the total exam timer; >0 = independent countdown for this pool/section.
        $tpools  = new xmldb_table('learnguard_pools');
        $fTlimit = new xmldb_field('timelimit', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'sortorder');
        if (!$dbman->field_exists($tpools, $fTlimit)) {
            $dbman->add_field($tpools, $fTlimit);
        }
        upgrade_mod_savepoint(true, 2026073003, 'learnguard');
    }

    if ($oldversion < 2026073004) {
        // Create learnguard_attempt_sections: records when each section started and its server-side
        // deadline, enabling submit_answer and autosave to reject saves after the section expires.
        if (!$dbman->table_exists('learnguard_attempt_sections')) {
            $t = new xmldb_table('learnguard_attempt_sections');
            $t->add_field('id',          XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $t->add_field('attemptid',   XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('catid',       XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('deadline',    XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $t->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $t->add_index('attemptid',   XMLDB_INDEX_NOTUNIQUE, ['attemptid']);
            $t->add_index('attempt_cat', XMLDB_INDEX_UNIQUE,    ['attemptid', 'catid']);
            $dbman->create_table($t);
        }
        upgrade_mod_savepoint(true, 2026073004, 'learnguard');
    }

    if ($oldversion < 2026073005) {
        // Add show_section_breaks toggle to the activity table.
        // 1 = show named section intro overlays and nav dividers (default for pool-based assessments).
        // 0 = show all questions seamlessly with no section UI.
        $tlg  = new xmldb_table('learnguard');
        $fSSB = new xmldb_field('show_section_breaks', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1', 'num_questions');
        if (!$dbman->field_exists($tlg, $fSSB)) {
            $dbman->add_field($tlg, $fSSB);
        }
        upgrade_mod_savepoint(true, 2026073005, 'learnguard');
    }

    return true;
}
