<?php
/**
 * Storage management — shows total disk usage for LearnShield media, allows filtering and deletion.
 *
 * @package    quizaccess_learnshield
 * @author     Michael Adeniran <michaeladeniransnr@gmail.com>
 * @copyright  2025 Michael Adeniran
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../../config.php');

require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$PAGE->set_context($context);
$PAGE->set_url('/mod/quiz/accessrule/learnshield/storage.php');
$PAGE->set_title('LearnShield Storage');
$PAGE->set_heading('LearnShield — Storage Management');

// Handle bulk delete.
$action = optional_param('action', '', PARAM_ALPHA);
if ($action === 'deleteall' && confirm_sesskey()) {
    $type = optional_param('type', 0, PARAM_INT);
    if ($type) {
        $DB->delete_records_select('quizaccess_learnshield_logs', 'imagetype = :t', ['t' => $type]);
    } else {
        $DB->delete_records_select('quizaccess_learnshield_logs', 'webcampicture IS NOT NULL', []);
    }
    redirect(new moodle_url('/mod/quiz/accessrule/learnshield/storage.php'), 'Deleted successfully.', 2);
}
if ($action === 'deleteids' && confirm_sesskey()) {
    $delIds = optional_param_array('delids', [], PARAM_INT);
    foreach ($delIds as $id) {
        $DB->delete_records('quizaccess_learnshield_logs', ['id' => (int)$id]);
    }
    redirect(new moodle_url('/mod/quiz/accessrule/learnshield/storage.php'), count($delIds) . ' items deleted.', 2);
}

// Gather storage stats.
$stats = $DB->get_records_sql(
    "SELECT imagetype,
            COUNT(*) AS item_count,
            SUM(OCTET_LENGTH(COALESCE(webcampicture, ''))) AS total_bytes
       FROM {quizaccess_learnshield_logs}
      WHERE webcampicture IS NOT NULL
      GROUP BY imagetype
      ORDER BY total_bytes DESC"
);

$grandTotal = 0;
foreach ($stats as $s) { $grandTotal += $s->total_bytes; }

function ls_fmtSize($bytes) {
    if ($bytes >= 1073741824) { return round($bytes / 1073741824, 1) . ' GB'; }
    if ($bytes >= 1048576)    { return round($bytes / 1048576, 1) . ' MB'; }
    if ($bytes >= 1024)       { return round($bytes / 1024, 1) . ' KB'; }
    return $bytes . ' B';
}

$typeLabels = [
    1 => '📸 Webcam Snapshot',
    2 => '🎥 360° Video / Environment Recording',
    3 => '🪪 Photo ID',
];

$filterType = optional_param('filter', 0, PARAM_INT);

$snapWhere = $filterType ? 'imagetype = :ft AND webcampicture IS NOT NULL' : 'webcampicture IS NOT NULL';
$snapParams = $filterType ? ['ft' => $filterType] : [];
$snaps = $DB->get_records_sql(
    "SELECT l.id, l.imagetype, l.parenttype, l.timemodified, u.firstname, u.lastname,
            q.name AS quizname,
            OCTET_LENGTH(COALESCE(webcampicture, '')) AS file_bytes
       FROM {quizaccess_learnshield_logs} l
       JOIN {user}           u  ON u.id = l.userid
       JOIN {course_modules} cm ON cm.id = l.quizid
       JOIN {quiz}           q  ON q.id = cm.instance
      WHERE $snapWhere
      ORDER BY l.timemodified DESC",
    $snapParams, 0, 100
);

echo $OUTPUT->header();
?>

<style>
body { font-family: system-ui, sans-serif; }
</style>

<div style="padding:24px;max-width:1200px;">
  <h2 style="margin-bottom:4px;">💾 Storage Management — LearnShield</h2>
  <p style="color:#6c757d;margin-bottom:24px;">Media stored by the LearnShield proctoring plugin.</p>

  <!-- Summary cards -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-bottom:24px;">
    <div style="background:#0f6cbf;color:#fff;border-radius:10px;padding:16px;text-align:center;">
      <div style="font-size:28px;font-weight:900;"><?php echo ls_fmtSize($grandTotal); ?></div>
      <div style="font-size:12px;opacity:.85;">Total Storage Used</div>
    </div>
    <?php foreach ($stats as $s): ?>
    <div style="background:#fff;border-radius:10px;padding:14px;box-shadow:0 1px 6px rgba(0,0,0,.08);cursor:pointer;"
         onclick="location.href='?filter=<?php echo (int)$s->imagetype; ?>'">
      <div style="font-size:16px;font-weight:700;color:#212529;"><?php echo ls_fmtSize($s->total_bytes); ?></div>
      <div style="font-size:12px;color:#6c757d;margin:2px 0;"><?php echo $typeLabels[$s->imagetype] ?? 'Type ' . $s->imagetype; ?></div>
      <div style="font-size:11px;color:#adb5bd;"><?php echo number_format($s->item_count); ?> items</div>
      <div style="margin-top:8px;background:#e9ecef;border-radius:4px;height:6px;overflow:hidden;">
        <div style="height:100%;background:#0f6cbf;border-radius:4px;width:<?php echo $grandTotal > 0 ? round($s->total_bytes / $grandTotal * 100) : 0; ?>%;"></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Controls -->
  <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;flex-wrap:wrap;">
    <select class="form-control" style="max-width:220px;" onchange="location.href='?filter='+this.value">
      <option value="">— All types —</option>
      <?php foreach ($typeLabels as $tv => $tl): ?>
      <option value="<?php echo $tv; ?>" <?php echo $filterType === $tv ? 'selected' : ''; ?>><?php echo $tl; ?></option>
      <?php endforeach; ?>
    </select>
    <?php if ($filterType): ?>
    <a href="?" class="btn btn-sm btn-outline-secondary">✕ Clear filter</a>
    <?php endif; ?>
    <div style="margin-left:auto;display:flex;gap:8px;align-items:center;">
      <label style="font-size:12px;cursor:pointer;display:flex;align-items:center;gap:5px;">
        <input type="checkbox" id="ls-stor-sel-all" onchange="lsStorSelAll(this.checked)" style="width:14px;height:14px;"> Select All
      </label>
      <button onclick="lsStorDeleteSelected()" class="btn btn-sm btn-danger" id="ls-stor-del-btn" style="display:none;">
        🗑 Delete Selected (<span id="ls-stor-sel-count">0</span>)
      </button>
      <?php if ($filterType): ?>
      <form method="post" style="display:inline;" onsubmit="return confirm('Delete ALL items of this type?');">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <input type="hidden" name="action" value="deleteall">
        <input type="hidden" name="type" value="<?php echo (int)$filterType; ?>">
        <button type="submit" class="btn btn-sm btn-outline-danger">🗑 Delete ALL <?php echo $typeLabels[$filterType] ?? ''; ?></button>
      </form>
      <?php endif; ?>
    </div>
  </div>

  <!-- Grid -->
  <?php if (empty($snaps)): ?>
  <div class="alert alert-info">No items found.</div>
  <?php else: ?>
  <form id="ls-stor-form" method="post">
    <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
    <input type="hidden" name="action" value="deleteids">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;">
    <?php foreach ($snaps as $s):
        $src = (new moodle_url('/mod/quiz/accessrule/learnshield/snapshot.php',['id'=>$s->id,'sesskey'=>sesskey()]))->out(false);
        $isVid = ($s->imagetype == 2 || $s->parenttype === 'environment_recording');
        $icon  = $typeLabels[$s->imagetype] ?? '📷';
        $name  = htmlspecialchars(fullname((object)['firstname'=>$s->firstname,'lastname'=>$s->lastname]));
    ?>
    <div style="background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 6px rgba(0,0,0,.08);position:relative;">
      <label style="position:absolute;top:6px;left:6px;z-index:2;cursor:pointer;">
        <input type="checkbox" name="delids[]" class="ls-stor-chk" value="<?php echo $s->id; ?>"
               style="width:16px;height:16px;accent-color:#dc3545;" onchange="lsStorChkChanged()">
      </label>
      <?php if ($isVid): ?>
      <video src="<?php echo $src; ?>" controls style="width:100%;height:110px;object-fit:cover;background:#111;"></video>
      <?php else: ?>
      <img src="<?php echo $src; ?>" loading="lazy" style="width:100%;height:110px;object-fit:cover;">
      <?php endif; ?>
      <div style="padding:6px 8px;">
        <div style="font-size:10px;font-weight:600;"><?php echo $icon; ?> <?php echo $name; ?></div>
        <div style="font-size:10px;color:#adb5bd;"><?php echo userdate($s->timemodified,'%d/%m/%y %H:%M'); ?></div>
        <div style="font-size:10px;color:#6c757d;"><?php echo ls_fmtSize($s->file_bytes); ?> · <?php echo format_string($s->quizname); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
  </form>
  <?php endif; ?>
</div>

<script>
function lsStorChkChanged() {
    var n = document.querySelectorAll('.ls-stor-chk:checked').length;
    var btn = document.getElementById('ls-stor-del-btn');
    var cnt = document.getElementById('ls-stor-sel-count');
    if (btn) { btn.style.display = n > 0 ? 'inline-block' : 'none'; }
    if (cnt) { cnt.textContent = n; }
}
function lsStorSelAll(v) {
    document.querySelectorAll('.ls-stor-chk').forEach(function(c){ c.checked = v; });
    lsStorChkChanged();
}
function lsStorDeleteSelected() {
    var n = document.querySelectorAll('.ls-stor-chk:checked').length;
    if (!n) { return; }
    if (!confirm('Delete ' + n + ' selected item(s)?')) { return; }
    document.getElementById('ls-stor-form').submit();
}
</script>

<?php echo $OUTPUT->footer(); ?>
