<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade steps for Learn Shield V1.
 *
 * @package    quizaccess_learnshield
 * @author     Michael Adeniran <michaeladeniransnr@gmail.com>
 * @copyright  2025 Michael Adeniran
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @link       https://www.linkedin.com/in/michaeladeniran/
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Upgrade the plugin schema.
 *
 * @param int $oldversion The version we are upgrading from.
 * @return bool
 */
function xmldb_quizaccess_learnshield_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    // Future upgrade steps go here.
    // Example pattern:
    // if ($oldversion < 2025060100) {
    //     // Add new column example.
    //     $table = new xmldb_table('quizaccess_learnshield_sessions');
    //     $field = new xmldb_field('new_field', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    //     if (!$dbman->field_exists($table, $field)) {
    //         $dbman->add_field($table, $field);
    //     }
    //     upgrade_plugin_savepoint(true, 2025060100, 'quizaccess', 'learnshield');
    // }

    return true;
}
