// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <http://www.gnu.org/licenses/>.

/**
 * LearnGuard SPA assessment controller.
 *
 * Single Page Application that orchestrates the entire assessment without page reloads:
 *  - Fullscreen enforcement (one request, persists via overlay)
 *  - Webcam capture and snapshot upload
 *  - AJAX question loading and submission
 *  - Proctoring event logging
 *  - Timer countdown
 *  - Auto-save every 30s
 *
 * @module     mod_learnguard/assessment
 * @author     Michael Adeniran <michaeladeniransnr@gmail.com>
 * @copyright  2025 Michael Adeniran
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define([
    'core/ajax',
    'core/notification',
    'core/str',
], function(Ajax, Notification, Str) {
    'use strict';

    /* -----------------------------------------------------------------------
     * State
     * -------------------------------------------------------------------- */
    var cfg = {};
    var state = {
        attemptid: 0,
        currentslot: 1,
        totalquestions: 0,
        timelimit: 0,
        timestart: 0,
        navigation: [],
        finished: false,
        suspended: false,
        riskScore: 0,
        riskLevel: 'low',
        webcamStream: null,
        snapshotTimer: null,
        pollTimer: null,
        autosaveTimer: null,
        countdownTimer: null,
        faceDetectionActive: false,
        lastMessageTime: 0,
    };

    /* -----------------------------------------------------------------------
     * DOM helpers
     * -------------------------------------------------------------------- */
    function el(id) { return document.getElementById(id); }

    function callWS(method, args) {
        return new Promise(function(resolve, reject) {
            Ajax.call([{
                methodname: method,
                args: args,
                done: resolve,
                fail: function(err) {
                    reject(err);
                },
            }]);
        });
    }

    /* -----------------------------------------------------------------------
     * Fullscreen management
     * -------------------------------------------------------------------- */
    var fsBlocker = null;

    function fsIsActive() {
        return !!(
            document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullScreenElement
        );
    }

    function enterFS() {
        var el = document.documentElement;
        var fn = el.requestFullscreen || el.webkitRequestFullscreen || el.mozRequestFullScreen;
        if (fn) {
            fn.call(el).catch(function() {
                // User must interact — show blocker.
                showFsBlocker();
            });
        }
    }

    function showFsBlocker() {
        if (!cfg.enablefullscreen || state.finished) { return; }
        if (fsBlocker) { fsBlocker.style.display = 'flex'; return; }

        fsBlocker = document.createElement('div');
        fsBlocker.id = 'lg-fs-blocker';
        fsBlocker.style.cssText = [
            'position:fixed', 'inset:0', 'background:rgba(0,0,0,0.95)',
            'display:flex', 'flex-direction:column', 'align-items:center',
            'justify-content:center', 'z-index:999999', 'color:#fff',
            'font-family:system-ui,sans-serif', 'text-align:center', 'padding:40px',
        ].join(';');

        var icon = document.createElement('div');
        icon.style.cssText = 'font-size:64px;margin-bottom:20px;';
        icon.textContent = '🛡️';

        var title = document.createElement('h2');
        title.style.cssText = 'margin-bottom:12px;font-size:24px;';
        title.textContent = 'Fullscreen Required';

        var msg = document.createElement('p');
        msg.style.cssText = 'color:#ccc;margin-bottom:24px;max-width:400px;';
        msg.textContent = 'This proctored assessment must be taken in fullscreen mode. ' +
            'Click the button below to continue.';

        var btn = document.createElement('button');
        btn.style.cssText = [
            'background:#0f6cbf', 'color:#fff', 'border:none', 'border-radius:6px',
            'padding:14px 32px', 'font-size:18px', 'cursor:pointer',
        ].join(';');
        btn.textContent = '↗ Return to Fullscreen';
        btn.addEventListener('click', function() {
            enterFS();
        });

        fsBlocker.appendChild(icon);
        fsBlocker.appendChild(title);
        fsBlocker.appendChild(msg);
        fsBlocker.appendChild(btn);
        document.body.appendChild(fsBlocker);
    }

    function hideFsBlocker() {
        if (fsBlocker) { fsBlocker.style.display = 'none'; }
    }

    function initFullscreen() {
        if (!cfg.enablefullscreen) { return; }

        // Enter FS immediately.
        enterFS();

        // Watch fullscreen changes.
        document.addEventListener('fullscreenchange', function() {
            if (!fsIsActive() && !state.finished) {
                showFsBlocker();
                logProctoringEvent('fullscreen_exit', {}, 'medium', 15);
            } else {
                hideFsBlocker();
            }
        });
        document.addEventListener('webkitfullscreenchange', function() {
            if (!fsIsActive() && !state.finished) {
                showFsBlocker();
            } else {
                hideFsBlocker();
            }
        });

        // Visibility change catches Alt+Tab.
        document.addEventListener('visibilitychange', function() {
            if (!document.hidden && !fsIsActive() && !state.finished) {
                showFsBlocker();
            }
        });

        // Window blur — catches switching to another app.
        window.addEventListener('blur', function() {
            setTimeout(function() {
                if (!fsIsActive() && !state.finished) { showFsBlocker(); }
            }, 50);
        });
    }

    /* -----------------------------------------------------------------------
     * Tab / window switch detection
     * -------------------------------------------------------------------- */
    function initTabDetection() {
        if (!cfg.enabletabdetect) { return; }

        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                logProctoringEvent('tab_switch', {}, 'medium', 10);
                showToast('⚠️ Switching tabs has been detected and logged.', 'warning');
            }
        });
    }

    /* -----------------------------------------------------------------------
     * Keyboard blocking
     * -------------------------------------------------------------------- */
    function initKeyBlock() {
        if (!cfg.enablekeyblock) { return; }

        var blocked = [
            'F1','F5','F11','F12',
        ];
        var blockedCtrl = [
            'a','c','v','x','u','s','p','j','i','k',
        ];
        var blockedAlt = [
            'Tab','F4',
        ];

        document.addEventListener('keydown', function(e) {
            if (blocked.indexOf(e.key) !== -1) {
                e.preventDefault();
                e.stopPropagation();
                logProctoringEvent('key_violation', {key: e.key}, 'low', 0);
                return;
            }
            if ((e.ctrlKey || e.metaKey) && blockedCtrl.indexOf(e.key.toLowerCase()) !== -1) {
                e.preventDefault();
                e.stopPropagation();
                logProctoringEvent('key_violation', {key: 'ctrl+' + e.key}, 'low', 0);
                return;
            }
            if (e.altKey && blockedAlt.indexOf(e.key) !== -1) {
                e.preventDefault();
                e.stopPropagation();
                logProctoringEvent('key_violation', {key: 'alt+' + e.key}, 'low', 0);
            }
        }, true);

        // Block right-click context menu.
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
    }

    /* -----------------------------------------------------------------------
     * Clipboard monitoring
     * -------------------------------------------------------------------- */
    function initClipboard() {
        if (!cfg.enableclipboard) { return; }

        document.addEventListener('copy', function() {
            logProctoringEvent('clipboard_copy', {}, 'low', 5);
        });
        document.addEventListener('paste', function() {
            logProctoringEvent('clipboard_paste', {}, 'low', 5);
        });
        document.addEventListener('cut', function() {
            logProctoringEvent('clipboard_cut', {}, 'low', 5);
        });
    }

    /* -----------------------------------------------------------------------
     * Webcam
     * -------------------------------------------------------------------- */
    function initWebcam() {
        if (!cfg.enablewebcam) { return; }

        navigator.mediaDevices.getUserMedia({video: true, audio: false})
            .then(function(stream) {
                state.webcamStream = stream;
                var camEl = el('lg-webcam-video');
                if (camEl) {
                    camEl.srcObject = stream;
                    camEl.play().catch(function() {});
                }
                startSnapshotTimer();
            })
            .catch(function(err) {
                logProctoringEvent('webcam_denied', {error: err.message || 'denied'}, 'high', 20);
                showToast('⚠️ Webcam access denied — this has been logged.', 'danger');
            });
    }

    function startSnapshotTimer() {
        var interval = cfg.snapinterval || 30000;
        state.snapshotTimer = setInterval(function() {
            captureAndUploadSnapshot('periodic');
        }, interval);
    }

    function captureAndUploadSnapshot(type) {
        if (!state.webcamStream || !state.attemptid) { return; }

        var video = el('lg-webcam-video');
        if (!video) { return; }

        var canvas = document.createElement('canvas');
        canvas.width = 320;
        canvas.height = 240;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, 320, 240);
        var dataUrl = canvas.toDataURL('image/jpeg', 0.7);

        callWS('mod_learnguard_send_snapshot', {
            attemptid: state.attemptid,
            imagedata: dataUrl,
            event_type: type,
        }).catch(function() {});
    }

    /* -----------------------------------------------------------------------
     * Risk score display
     * -------------------------------------------------------------------- */
    function updateRiskDisplay() {
        var badge = el('lg-risk-badge');
        if (!badge) { return; }
        var colours = {low: '#28a745', medium: '#fd7e14', high: '#dc3545'};
        badge.style.background = colours[state.riskLevel] || '#6c757d';
        badge.textContent = '🛡 Risk: ' + state.riskScore + ' (' + state.riskLevel + ')';
    }

    /* -----------------------------------------------------------------------
     * Timer
     * -------------------------------------------------------------------- */
    function initTimer() {
        if (!state.timelimit) { return; }

        var timerEl = el('lg-timer');
        if (!timerEl) { return; }
        timerEl.style.display = 'block';

        state.countdownTimer = setInterval(function() {
            var elapsed = Math.floor(Date.now() / 1000) - state.timestart;
            var remaining = state.timelimit - elapsed;

            if (remaining <= 0) {
                clearInterval(state.countdownTimer);
                timerEl.textContent = '⏱ 0:00';
                timerEl.style.color = '#dc3545';
                autoFinishAttempt();
                return;
            }

            var mins = Math.floor(remaining / 60);
            var secs = remaining % 60;
            timerEl.textContent = '⏱ ' + mins + ':' + (secs < 10 ? '0' : '') + secs;

            if (remaining <= 300) {
                timerEl.style.color = '#fd7e14';
            }
            if (remaining <= 60) {
                timerEl.style.color = '#dc3545';
            }
        }, 1000);
    }

    function autoFinishAttempt() {
        if (state.finished) { return; }
        showToast('⏱ Time is up! Submitting your assessment…', 'warning');
        finishAttempt();
    }

    /* -----------------------------------------------------------------------
     * Poll for suspension / messages
     * -------------------------------------------------------------------- */
    function startPolling() {
        state.pollTimer = setInterval(function() {
            if (!state.attemptid || state.finished) { return; }
            callWS('mod_learnguard_get_messages', {
                attemptid: state.attemptid,
                since: state.lastMessageTime,
            }).then(function(data) {
                state.lastMessageTime = Math.floor(Date.now() / 1000);
                if (data.suspended && !state.suspended) {
                    state.suspended = true;
                    showSuspendedScreen();
                }
                state.riskScore = data.risk_score;
                state.riskLevel = data.risk_level;
                updateRiskDisplay();
            }).catch(function() {});
        }, 15000);
    }

    /* -----------------------------------------------------------------------
     * Auto-save
     * -------------------------------------------------------------------- */
    function startAutosave() {
        state.autosaveTimer = setInterval(function() {
            if (state.finished || !state.attemptid) { return; }
            var formData = collectCurrentFormData();
            if (!formData.length) { return; }

            callWS('mod_learnguard_autosave', {
                attemptid: state.attemptid,
                slot: state.currentslot,
                responsedata: formData,
            }).then(function() {
                showToast('💾 Answer saved automatically', 'info', 2000);
            }).catch(function() {});
        }, 30000);
    }

    function collectCurrentFormData() {
        var container = el('lg-question-container');
        if (!container) { return []; }
        var inputs = container.querySelectorAll('input, select, textarea');
        var data = [];
        inputs.forEach(function(inp) {
            if (!inp.name) { return; }
            if ((inp.type === 'checkbox' || inp.type === 'radio') && !inp.checked) { return; }
            data.push({name: inp.name, value: inp.value || ''});
        });
        return data;
    }

    /* -----------------------------------------------------------------------
     * Proctoring event logger
     * -------------------------------------------------------------------- */
    var eventMap = {
        tab_switch:       {severity: 'medium', score: 10},
        fullscreen_exit:  {severity: 'medium', score: 15},
        face_missing:     {severity: 'high',   score: 20},
        face_multiple:    {severity: 'high',   score: 25},
        clipboard_copy:   {severity: 'low',    score: 5},
        clipboard_paste:  {severity: 'low',    score: 5},
        clipboard_cut:    {severity: 'low',    score: 5},
        key_violation:    {severity: 'low',    score: 0},
        webcam_denied:    {severity: 'high',   score: 20},
    };

    function logProctoringEvent(eventtype, data, severity, score) {
        if (!state.attemptid) { return; }
        var meta = eventMap[eventtype] || {};
        var sev   = severity || meta.severity || 'low';
        var impact = (score !== undefined) ? score : (meta.score || 0);

        callWS('mod_learnguard_log_event', {
            attemptid:   state.attemptid,
            eventtype:   eventtype,
            eventdata:   JSON.stringify(data || {}),
            severity:    sev,
            scoreimpact: impact,
        }).then(function(resp) {
            state.riskScore = resp.risk_score;
            state.riskLevel = resp.risk_level;
            updateRiskDisplay();

            // Auto-suspend check.
            if (cfg.autosuspend_score > 0 && state.riskScore >= cfg.autosuspend_score && !state.suspended) {
                state.suspended = true;
                showSuspendedScreen();
            }
        }).catch(function() {});
    }

    /* -----------------------------------------------------------------------
     * Toast notifications
     * -------------------------------------------------------------------- */
    var toastContainer = null;
    function showToast(message, type, duration) {
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.style.cssText = [
                'position:fixed', 'top:16px', 'right:16px', 'z-index:9998',
                'display:flex', 'flex-direction:column', 'gap:8px', 'max-width:360px',
            ].join(';');
            document.body.appendChild(toastContainer);
        }

        var colours = {
            info: '#0d6efd', success: '#198754', warning: '#fd7e14',
            danger: '#dc3545', secondary: '#6c757d',
        };

        var toast = document.createElement('div');
        toast.style.cssText = [
            'background:' + (colours[type] || colours.info),
            'color:#fff', 'padding:10px 16px', 'border-radius:6px',
            'font-size:14px', 'font-family:system-ui,sans-serif',
            'box-shadow:0 4px 12px rgba(0,0,0,0.3)',
            'transition:opacity 0.3s',
        ].join(';');
        toast.textContent = message;
        toastContainer.appendChild(toast);

        var delay = typeof duration === 'number' ? duration : 4000;
        setTimeout(function() {
            toast.style.opacity = '0';
            setTimeout(function() {
                if (toast.parentNode) { toast.parentNode.removeChild(toast); }
            }, 300);
        }, delay);
    }

    /* -----------------------------------------------------------------------
     * Navigation panel
     * -------------------------------------------------------------------- */
    function renderNavigation() {
        var nav = el('lg-nav-panel');
        if (!nav) { return; }
        nav.innerHTML = '';

        var colours = {
            'correct':        '#28a745',
            'partiallycorrect': '#fd7e14',
            'incorrect':      '#dc3545',
            'complete':       '#0d6efd',
            'todo':           '#dee2e6',
            'invalid':        '#adb5bd',
        };

        state.navigation.forEach(function(item) {
            var btn = document.createElement('button');
            btn.className = 'lg-nav-btn';
            btn.textContent = item.slot;
            btn.style.cssText = [
                'width:36px', 'height:36px', 'border-radius:4px',
                'border:2px solid ' + (item.slot === state.currentslot ? '#0f6cbf' : '#ccc'),
                'background:' + (colours[item.state] || '#f8f9fa'),
                'cursor:pointer', 'font-size:13px', 'font-weight:600',
                'color:' + (item.answered ? '#fff' : '#333'),
            ].join(';');
            btn.title = 'Question ' + item.slot;
            btn.addEventListener('click', function() {
                navigateToSlot(item.slot);
            });
            nav.appendChild(btn);
        });
    }

    function updateNavState(slot, answered) {
        state.navigation.forEach(function(n) {
            if (n.slot === slot) {
                n.answered = answered;
                n.state = answered ? 'complete' : 'todo';
            }
        });
        renderNavigation();
    }

    /* -----------------------------------------------------------------------
     * Question loading
     * -------------------------------------------------------------------- */
    function navigateToSlot(slot) {
        if (slot < 1 || slot > state.totalquestions) { return; }
        if (slot === state.currentslot) { return; }
        state.currentslot = slot;
        loadQuestion(slot);
    }

    function loadQuestion(slot) {
        var container = el('lg-question-container');
        var progress  = el('lg-progress');
        if (!container) { return; }

        container.innerHTML = '<div style="text-align:center;padding:40px;color:#6c757d;">' +
            '<div class="lg-spinner"></div><p>Loading question…</p></div>';

        if (progress) {
            progress.textContent = 'Question ' + slot + ' of ' + state.totalquestions;
        }

        callWS('mod_learnguard_get_question', {
            attemptid: state.attemptid,
            slot: slot,
            review: false,
        }).then(function(data) {
            container.innerHTML = data.html;
            state.currentslot = data.slot;

            // Re-run any inline scripts (Moodle question scripts).
            container.querySelectorAll('script').forEach(function(old) {
                var s = document.createElement('script');
                if (old.src) { s.src = old.src; } else { s.textContent = old.textContent; }
                old.parentNode.replaceChild(s, old);
            });

            renderNavigation();
            updateNavigationButtons(slot, data.totalquestions);
        }).catch(function(err) {
            container.innerHTML = '<div class="alert alert-danger">' +
                'Failed to load question. Please try again.<br><small>' +
                (err.message || '') + '</small></div>';
        });
    }

    function updateNavigationButtons(slot, total) {
        var prevBtn = el('lg-prev-btn');
        var nextBtn = el('lg-next-btn');
        var submitBtn = el('lg-submit-btn');

        if (prevBtn) {
            prevBtn.disabled = (slot <= 1);
            prevBtn.style.opacity = (slot <= 1) ? '0.4' : '1';
        }
        if (nextBtn) {
            nextBtn.style.display = (slot < total) ? 'inline-block' : 'none';
        }
        if (submitBtn) {
            submitBtn.style.display = (slot >= total) ? 'inline-block' : 'none';
        }
    }

    /* -----------------------------------------------------------------------
     * Answer submission
     * -------------------------------------------------------------------- */
    function submitCurrentAnswer(andFinish) {
        var formData = collectCurrentFormData();

        callWS('mod_learnguard_submit_answer', {
            attemptid:    state.attemptid,
            slot:         state.currentslot,
            responsedata: formData,
        }).then(function(data) {
            updateNavState(state.currentslot, true);

            if (andFinish || data.finished) {
                finishAttempt();
            } else if (data.nextslot > 0) {
                state.currentslot = data.nextslot;
                loadQuestion(data.nextslot);
            }
        }).catch(function(err) {
            showToast('Error saving answer: ' + (err.message || 'Please try again.'), 'danger');
        });
    }

    function finishAttempt() {
        if (state.finished) { return; }

        callWS('mod_learnguard_finish_attempt', {
            attemptid: state.attemptid,
        }).then(function(data) {
            state.finished = true;
            clearTimers();
            showResultScreen(data);
        }).catch(function(err) {
            showToast('Failed to submit: ' + (err.message || 'Please try again.'), 'danger');
        });
    }

    /* -----------------------------------------------------------------------
     * Screen states
     * -------------------------------------------------------------------- */
    function showLoadingScreen() {
        var loading = el('lg-loading');
        if (loading) { loading.style.display = 'flex'; }
        var spa = el('lg-spa-container');
        if (spa) { spa.style.display = 'none'; }
    }

    function hideLoadingScreen() {
        var loading = el('lg-loading');
        if (loading) { loading.style.display = 'none'; }
    }

    function showInstructionsScreen() {
        var spa = el('lg-spa-container');
        if (!spa) { return; }

        var instructions = cfg.instructions || '';
        spa.innerHTML = buildInstructionsHTML(instructions);
        spa.style.display = 'block';

        var startBtn = el('lg-start-btn');
        if (startBtn) {
            startBtn.addEventListener('click', function() {
                beginAssessment();
            });
        }
    }

    function buildInstructionsHTML(instructions) {
        return '<div style="max-width:700px;margin:0 auto;padding:40px 24px;font-family:system-ui,sans-serif;">' +
            '<h2 style="margin-bottom:8px;">📋 Assessment Instructions</h2>' +
            (instructions
                ? '<div style="background:#f8f9fa;border-radius:8px;padding:20px;margin-bottom:24px;">' +
                  instructions + '</div>'
                : '<p style="color:#6c757d;margin-bottom:24px;">No special instructions. You may begin.</p>') +
            (cfg.proctoring
                ? '<div style="background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:16px;margin-bottom:24px;">' +
                  '<strong>⚠️ This assessment is proctored.</strong><br>' +
                  'Your webcam, screen activity, and keyboard actions will be monitored throughout.</div>'
                : '') +
            '<button id="lg-start-btn" style="background:#0f6cbf;color:#fff;border:none;border-radius:6px;' +
            'padding:14px 36px;font-size:18px;cursor:pointer;">▶ Begin Assessment</button>' +
            '</div>';
    }

    function showAssessmentShell() {
        var spa = el('lg-spa-container');
        if (!spa) { return; }

        spa.innerHTML = buildAssessmentShellHTML();
        spa.style.display = 'block';

        // Wire up navigation buttons.
        var prevBtn = el('lg-prev-btn');
        var nextBtn = el('lg-next-btn');
        var submitBtn = el('lg-submit-btn');

        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                if (state.currentslot > 1) {
                    submitCurrentAnswer(false);
                }
            });
        }
        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                submitCurrentAnswer(false);
            });
        }
        if (submitBtn) {
            submitBtn.addEventListener('click', function() {
                if (confirm('Are you sure you want to submit your assessment? You cannot change your answers after submission.')) {
                    submitCurrentAnswer(true);
                }
            });
        }
    }

    function buildAssessmentShellHTML() {
        return '<div style="display:flex;flex-direction:column;height:100vh;font-family:system-ui,sans-serif;">' +

            // Top bar.
            '<div style="display:flex;align-items:center;justify-content:space-between;' +
            'background:#0f6cbf;color:#fff;padding:10px 16px;flex-shrink:0;">' +
            '<div style="font-weight:700;font-size:16px;">🛡 LearnGuard Assessment</div>' +
            '<div style="display:flex;gap:12px;align-items:center;">' +
            '<div id="lg-progress" style="font-size:14px;"></div>' +
            '<div id="lg-timer" style="display:none;font-size:14px;font-weight:700;"></div>' +
            '<div id="lg-risk-badge" style="background:#28a745;color:#fff;padding:4px 10px;' +
            'border-radius:12px;font-size:12px;font-weight:600;">🛡 Risk: 0 (low)</div>' +
            '</div>' +
            '</div>' +

            // Main content area.
            '<div style="display:flex;flex:1;overflow:hidden;">' +

            // Question area.
            '<div style="flex:1;overflow-y:auto;padding:24px;" id="lg-question-wrapper">' +
            '<div id="lg-question-container"></div>' +
            '<div style="display:flex;gap:12px;margin-top:24px;justify-content:space-between;">' +
            '<button id="lg-prev-btn" style="background:#6c757d;color:#fff;border:none;' +
            'border-radius:6px;padding:10px 20px;cursor:pointer;font-size:14px;">← Previous</button>' +
            '<div style="display:flex;gap:8px;">' +
            '<button id="lg-next-btn" style="background:#0f6cbf;color:#fff;border:none;' +
            'border-radius:6px;padding:10px 24px;cursor:pointer;font-size:14px;">Save & Next →</button>' +
            '<button id="lg-submit-btn" style="display:none;background:#28a745;color:#fff;border:none;' +
            'border-radius:6px;padding:10px 24px;cursor:pointer;font-size:14px;">✔ Submit Assessment</button>' +
            '</div></div></div>' +

            // Side panel.
            '<div style="width:200px;border-left:1px solid #dee2e6;padding:16px;overflow-y:auto;' +
            'background:#f8f9fa;flex-shrink:0;">' +

            // Webcam.
            (cfg.enablewebcam
                ? '<video id="lg-webcam-video" autoplay muted playsinline ' +
                  'style="width:100%;border-radius:6px;margin-bottom:12px;background:#000;"></video>'
                : '') +

            // Question navigator.
            '<div style="font-size:12px;font-weight:600;color:#6c757d;margin-bottom:8px;">QUESTIONS</div>' +
            '<div id="lg-nav-panel" style="display:flex;flex-wrap:wrap;gap:4px;"></div>' +

            '</div></div></div>';
    }

    function showResultScreen(data) {
        var spa = el('lg-spa-container');
        if (!spa) { return; }

        var pct = data.maxgrade > 0 ? Math.round((data.grade / data.maxgrade) * 100) : 0;
        var colour = pct >= 70 ? '#28a745' : (pct >= 50 ? '#fd7e14' : '#dc3545');

        spa.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;' +
            'justify-content:center;height:100vh;font-family:system-ui,sans-serif;text-align:center;padding:40px;">' +
            '<div style="font-size:64px;margin-bottom:16px;">✅</div>' +
            '<h2 style="margin-bottom:8px;">Assessment Submitted</h2>' +
            '<p style="color:#6c757d;margin-bottom:24px;">Your attempt has been recorded.</p>' +
            '<div style="background:' + colour + ';color:#fff;border-radius:12px;' +
            'padding:24px 48px;margin-bottom:24px;">' +
            '<div style="font-size:48px;font-weight:700;">' + pct + '%</div>' +
            '<div style="font-size:16px;">' + data.grade.toFixed(1) + ' / ' + data.maxgrade + ' marks</div>' +
            '</div>' +
            '<a href="' + cfg.wwwroot + '/course/view.php?id=' + cfg.courseid + '" ' +
            'style="background:#6c757d;color:#fff;padding:12px 24px;border-radius:6px;' +
            'text-decoration:none;font-size:15px;">← Back to Course</a>' +
            '</div>';
    }

    function showSuspendedScreen() {
        clearTimers();
        var spa = el('lg-spa-container');
        if (!spa) { return; }

        spa.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;' +
            'justify-content:center;height:100vh;font-family:system-ui,sans-serif;text-align:center;padding:40px;">' +
            '<div style="font-size:64px;margin-bottom:16px;">⛔</div>' +
            '<h2 style="color:#dc3545;margin-bottom:8px;">Attempt Suspended</h2>' +
            '<p style="color:#6c757d;margin-bottom:24px;">Your attempt has been suspended due to integrity violations.<br>' +
            'Please contact your instructor.</p>' +
            '<a href="' + cfg.wwwroot + '/course/view.php?id=' + cfg.courseid + '" ' +
            'style="background:#6c757d;color:#fff;padding:12px 24px;border-radius:6px;' +
            'text-decoration:none;">← Back to Course</a>' +
            '</div>';
    }

    /* -----------------------------------------------------------------------
     * Start flow
     * -------------------------------------------------------------------- */
    function beginAssessment() {
        var spa = el('lg-spa-container');
        if (spa) {
            spa.innerHTML = '<div style="text-align:center;padding:60px;color:#6c757d;">' +
                '<div class="lg-spinner"></div><p>Starting assessment…</p></div>';
            spa.style.display = 'block';
        }

        callWS('mod_learnguard_start_attempt', {cmid: cfg.cmid})
            .then(function(data) {
                state.attemptid      = data.attemptid;
                state.currentslot    = data.currentslot;
                state.totalquestions = data.totalquestions;
                state.timelimit      = data.timelimit;
                state.timestart      = data.timestart;
                state.navigation     = data.navigation;

                showAssessmentShell();
                initTimer();
                initWebcam();
                startAutosave();
                startPolling();
                loadQuestion(state.currentslot);
                renderNavigation();
                enterFS();
            })
            .catch(function(err) {
                if (spa) {
                    spa.innerHTML = '<div class="alert alert-danger" style="margin:40px auto;max-width:600px;">' +
                        'Failed to start assessment: ' + (err.message || 'Please try again.') + '</div>';
                }
            });
    }

    function beginResumedAssessment() {
        state.attemptid = cfg.attemptid;
        showAssessmentShell();

        callWS('mod_learnguard_get_attempt_state', {attemptid: state.attemptid})
            .then(function(data) {
                state.currentslot    = data.currentslot;
                state.navigation     = data.navigation;
                state.totalquestions = data.navigation.length;
                state.riskScore      = data.risk_score;
                state.riskLevel      = data.risk_level;

                if (data.suspended) {
                    showSuspendedScreen();
                    return;
                }

                initTimer();
                initWebcam();
                startAutosave();
                startPolling();
                loadQuestion(state.currentslot);
                renderNavigation();
                updateRiskDisplay();
                enterFS();
            });
    }

    /* -----------------------------------------------------------------------
     * Cleanup
     * -------------------------------------------------------------------- */
    function clearTimers() {
        if (state.snapshotTimer)  { clearInterval(state.snapshotTimer);  }
        if (state.pollTimer)      { clearInterval(state.pollTimer);      }
        if (state.autosaveTimer)  { clearInterval(state.autosaveTimer);  }
        if (state.countdownTimer) { clearInterval(state.countdownTimer); }
    }

    /* -----------------------------------------------------------------------
     * Public init
     * -------------------------------------------------------------------- */
    return {
        init: function(config) {
            cfg = config || {};

            // Hide the PHP-rendered loading spinner and show the SPA area.
            hideLoadingScreen();

            // If we are a teacher/manager, show the teacher view and stop.
            if (cfg.canManage && !cfg.canAttempt) {
                var teacherView = el('lg-teacher-view');
                if (teacherView) { teacherView.style.display = 'block'; }
                return;
            }

            // Proctoring setup (tab detection + key blocking start immediately).
            initFullscreen();
            initTabDetection();
            initKeyBlock();
            initClipboard();

            // If there is an existing in-progress attempt, resume it.
            if (cfg.attemptid && cfg.attemptid > 0) {
                beginResumedAssessment();
            } else {
                // Show instructions, student starts manually.
                var spa = el('lg-spa-container');
                if (spa) { spa.style.display = 'block'; }
                showInstructionsScreen();
            }
        },
    };
});
